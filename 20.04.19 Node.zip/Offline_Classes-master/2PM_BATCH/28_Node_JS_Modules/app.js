// Load the module
const os = require('os');
const fs = require('fs');

// Load Custom Module
const util = require('./util');


// Total Memory
let totalMemory = os.totalmem();
console.log(`Total Mem : ${totalMemory}`);

// Free Memory
let freeMemory = os.freemem();
console.log(`Free Mem : ${freeMemory}`);

// Host Name
let hostName = os.hostname();
console.log(`HostName : ${hostName}`);

// HomeDir
let homeDir = os.homedir();
console.log(`Home Dir : ${homeDir}`);

// UserInfo
let sysAdmin = os.userInfo().username;
console.log(sysAdmin);

// File System Module
// Write a File
/*fs.writeFile('data.txt',"Good Morning",'utf8',(err) => {
    if(err) throw  err;
    console.log('Data added to a file');
});*/

// Read a file Data
/*fs.readFile('data.txt','utf8',(err,data) => {
    if(err) throw  err;
    console.log(data);
});*/

// Create a Folder / Directory
fs.mkdir('util/data',{recursive : true},(err) => {
    if(err) throw  err;
    fs.readFile('data.txt','utf8',(err,data) => {
        if(err) throw  err;
        fs.writeFile('util/data/employee.txt',data,(err) => {
            if(err) throw  err;
            console.log('data is added');
        });
    });
});

// Custom Module
let reverseString = util.reverseString('Good Morning');
console.log(reverseString);

// Save Data
let data = "Welcome to Node JS";
let fileName = 'welcome.txt';
util.saveData(data,fileName);

// Save Object
let employee = {
    name : 'Rajan',
    age : 35,
    designation : 'Tech Lead',
    company: 'Infosys'
};
util.saveObject(employee,'employee.json');