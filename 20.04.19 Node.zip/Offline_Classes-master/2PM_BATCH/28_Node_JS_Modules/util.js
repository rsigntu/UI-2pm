const fs = require('fs');

// Function 1
let reverseString = (str) => {
  let tempStr = '';
  for(let i = str.length-1; i>=0 ; i--){
      tempStr += str.charAt(i);
  }
  return tempStr;
};

// Save Data
let saveData = (data,fileName) => {
    fs.writeFile(fileName,data,'utf8',(err) => {
        if(err) throw err;
        console.log('data is added');
    });
};

// Save Object
let saveObject = (object,fileName) => {
    fs.writeFile(fileName,JSON.stringify(object),'utf8',(err) => {
        if(err) throw err;
        console.log('Object is added');
    });
};

module.exports = {
    reverseString,
    saveData,
    saveObject
};