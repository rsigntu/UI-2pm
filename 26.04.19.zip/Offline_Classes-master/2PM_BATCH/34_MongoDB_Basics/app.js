const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

// Connection URL
const url = 'mongodb://localhost:27017';

// Database Name
const dbName = 'showroom';

// Use connect method to connect to the server
MongoClient.connect(url, (err, client) => {
    assert.equal(null, err);
    console.log("Connected successfully to Database");

    const db = client.db(dbName);

    insertDocuments(db, function() {
        client.close();
    });
});

let employees=[{name:'John',age:45,designation:'Manager',active:true},
    {name:'Wilson',age:55,designation:'Sr. Manager',active:false},
    {name:'Ramesh',age:25,designation:'Software Engineer',active:true},
    {name:'Laura',age:23,designation:'Trainee',active:false}];

const insertDocuments = function(db, callback) {
    // Get the documents collection
    const collection = db.collection('workers');
    // Insert some documents
    collection.insertMany(employees, function(err, result) {
        assert.equal(err, null);
        assert.equal(4, result.result.n);
        assert.equal(4, result.ops.length);
        console.log("Inserted 4 documents into the collection");
        callback(result);
    });
};