const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const _ = require('lodash');
// Get the Database connection Object
const getDB = require('../database/dbConnection').getDB;

// create application/x-www-form-urlencoded parser
const urlencodedParser = bodyParser.urlencoded({ extended: false });

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

/* GET Sign-In page. */
router.get('/signin', function(req, res, next) {
    res.render('signin',{message : ''});
});

/* Get Request for Dashboard. */
router.get('/dashboard', function(req, res, next) {
    const db = getDB();
    let categoryCount = 0;
    let categoriesArray = [];
    // getting Category details
    db.collection('categories').find({}).toArray((err,categories) => {
        if(err) throw err;
        console.log(categories);
        categoryCount = categories.length;
        categoriesArray = categories;
    });
    db.collection('tasks').find({}).toArray((err,tasks) => {
        if(err) throw err;
        console.log(tasks);
        let taskCount = tasks.length;
        res.render('dashboard',{tasks : tasks ,categories :categoriesArray , taskCount : taskCount , categoryCount : categoryCount});
    });

});

/* GET Request for Tasks Page. */
router.get('/tasks', function(req, res, next) {
    const db = getDB();

    // getting task details
    db.collection('tasks').find({}).toArray((err,tasks) => {
        if(err) throw err;
        console.log(tasks);
        let taskCount = tasks.length;
        res.render('tasks',{tasks : tasks});
    });
});

/* POST requests for Task Modal */
router.post('/add-task', urlencodedParser, function (req, res) {
    const db = getDB();
    let taskData = {
        task_name : req.body.task_name,
        employee_name : req.body.employee_name,
        employee_email : req.body.employee_email,
        task_level : req.body.task_level,
        task_category : req.body.task_category,
        description : req.body.description
    };
    console.log(taskData);
    // insertion of tasks
    db.collection('tasks').insertOne(taskData,(err , data) => {
        if(err) throw err;
    });
    let categoryCount = 0;
    let categoriesArray = 0;
    // getting Category details
    db.collection('categories').find({}).toArray((err,categories) => {
        if(err) throw err;
        console.log(categories);
        categoryCount = categories.length;
        categoriesArray = categories;
    });
    // getting task details
    db.collection('tasks').find({}).toArray((err,tasks) => {
        if(err) throw err;
        console.log(tasks);
        let taskCount = tasks.length;
        res.render('dashboard',{tasks : tasks , categories : categoriesArray, taskCount : taskCount , categoryCount : categoryCount});
    });
});

/* GET Request for Categories Page. */
router.get('/categories', function(req, res, next) {
    const db = getDB();

    // getting task details
    db.collection('tasks').find({}).toArray((err,tasks) => {
        if(err) throw err;
        console.log(tasks);
        let taskCount = tasks.length;
        res.render('categories',{tasks : tasks});
    });
});

/* POST add-categories */
router.post('/add-category', urlencodedParser, function (req, res) {
    const db = getDB();
    let categoryData = {
        category_name : req.body.category_name,
        create_date : new Date().toLocaleDateString()
    };
    console.log(categoryData);
    // insertion of category
    db.collection('categories').insertOne(categoryData,(err , data) => {
        if(err) throw err;
    });
    let taskCount = 0;
    // getting task details
    let newTasks = [];
    db.collection('tasks').find({}).toArray((err,tasks) => {
        if(err) throw err;
        console.log(tasks);
        taskCount = tasks.length;
        newTasks = tasks;
    });
    // getting Category details
    db.collection('categories').find({}).toArray((err,categories) => {
        if(err) throw err;
        console.log(categories);
        let categoryCount = categories.length;
        res.render('dashboard',{tasks : newTasks , categories :categories  , taskCount : taskCount , categoryCount : categoryCount});
    });
});


/* GET Request for Categories Page. */
router.get('/employees', function(req, res, next) {
    res.render('employees');
});


/* POSt Sign-In page. */
router.post('/signin', urlencodedParser, function (req, res) {
    const db = getDB();
    let userData = {
        username : req.body.username,
        password : req.body.password
    };

    db.collection('user').findOne({username : userData.username ,
        password : userData.password}, (err, document) => {
        if(!(_.isNull(document))){
            let categoryCount = 0;
            let categoryArray = [];
            // getting Category details
            db.collection('categories').find({}).toArray((err,categories) => {
                if(err) throw err;
                console.log(categories);
                categoryCount = categories.length;
                categoryArray = categories;
            });
            // getting task details
            db.collection('tasks').find({}).toArray((err,tasks) => {
                if(err) throw err;
                console.log(tasks);
                let taskCount = tasks.length;
                res.render('dashboard',{tasks : tasks , categories : categoryArray, taskCount : taskCount , categoryCount : categoryCount});
            });
        }
        else{
            res.render('signin',{message : 'Wrong Credentials'});
        }
    });
});

/* GET Sign-Up page. */
router.get('/signup', function(req, res, next) {
    res.render('signup');
});

/* POSt Sign-Up page. */
router.post('/signup', urlencodedParser, function (req, res) {
    const db = getDB();
    let userData = {
        first_name : req.body.first_name,
        last_name : req.body.last_name,
        username : req.body.username,
        email : req.body.email,
        password : req.body.password,
        c_password : req.body.c_password
    };
    console.log(userData);
    db.collection('user').insertOne(userData,(err , data) => {
        if(err) throw err;
    });
    res.render('signup_success', {userData : userData});
});

module.exports = router;
