$("#demo1").myfunc({divFact:10,eventListenerType:'keyup'});
$("#demo2").myfunc({divFact:10,eventListenerType:'keyup'});
$("#demo3").myfunc({divFact:10,eventListenerType:'keyup'});