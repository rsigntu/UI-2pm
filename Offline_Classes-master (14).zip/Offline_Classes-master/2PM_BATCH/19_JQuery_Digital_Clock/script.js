// Indian Date
setInterval(() => {
    let dateTime = fetchDateTime('Asia/Kolkata');
    $('#indian-time').text(dateTime.time);
    $('#indian-date').text(dateTime.date);
},1000);

// USA DATE
setInterval(() => {
    let dateTime = fetchDateTime('America/New_York');
    $('#usa-time').text(dateTime.time);
    $('#usa-date').text(dateTime.date);
},1000);

// CHINA DATE
setInterval(() => {
    let dateTime = fetchDateTime('Asia/Shanghai');
    $('#china-time').text(dateTime.time);
    $('#china-date').text(dateTime.date);
},1000);

// fetchDateTime
let fetchDateTime = (timeZone) => {
    let today = new Date();
    let options = {
        timeZone : timeZone
    };
    let time = today.toLocaleTimeString('en-US',options);
    let date = today.toLocaleDateString('en-US',options);
    return {time : time , date : date};
};