$.validator.setDefaults( {
    submitHandler: function () {
        alert( "submitted!" );
    }
});

// Form Validation Logic
$('#register-form').validate({
    rules : {
        firstName : {
            required : true,
            minlength : 5
        },
        lastName : {
            required : true,
            minlength : 5
        },
        userName : {
            required : true,
            minlength : 5
        },
        email : {
            required : true,
            email: true
        },
        password : {
            required : true,
            minlength : 5
        },
        c_password : {
            required : true,
            minlength : 5,
            equalTo: "#password"
        },
        check : {
            required : true
        }
    },
    messages : {
        firstName : {
            required : 'Required FirstName',
            minlength : 'Provide at least 5 letters for FirstName'
        },
        lastName : {
            required : 'Required LastName',
            minlength : 'Provide at least 5 letters for LastName'
        },
        userName : {
            required : 'Required UserName',
            minlength : 'Provide at least 5 letters for UserName'
        },
        email : {
            required : 'Required an Email',
            email: 'Provide a proper Email'
        },
        password : {
            required : 'Required Password',
            minlength : 'Provide at least 5 letters for Password'
        },
        c_password : {
            required : 'Required Confirm Password',
            minlength : 'Provide at least 5 letters for Confirm Password',
            equalTo: "Both the Passwords doesn't Matched"
        },
        check : {
            required : 'Please Accept the Terms & Conditions'
        }
    },
    errorPlacement: function ( error, element ) {
        // Add the `invalid-feedback` class to the error element
        error.addClass( "invalid-feedback" );

        if ( element.prop( "type" ) === "checkbox" ) {
            error.insertAfter( element.next( "label" ) );
        } else {
            error.insertAfter( element );
        }
    },
    highlight: function ( element, errorClass, validClass ) {
        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
    },
    unhighlight: function (element, errorClass, validClass) {
        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
    }
});

