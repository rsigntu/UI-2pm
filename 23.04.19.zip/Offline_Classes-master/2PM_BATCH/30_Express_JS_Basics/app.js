const path = require('path');
const express = require('express');
const app = express();

const hostname = '127.0.0.1';
const port = 3000;

// for html file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname,'index.html'));
});

// for json data
app.get('/json', (req, res) => {
    let employee = {
        name : 'John',
        age : 40,
        designation : 'Manager'
    };
    res.json(employee);
});

// download
app.get('/download', (req, res) => {
    res.download(path.join(__dirname,'abc.pdf'));
});

app.listen(port,hostname, () => console.log(`Example app listening on port ${port}!`));