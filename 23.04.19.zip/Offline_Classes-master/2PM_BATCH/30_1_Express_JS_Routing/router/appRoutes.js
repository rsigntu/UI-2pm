const path = require('path');

// map the application routes
let mapRoutes = (app) => {

    // home page
    app.get('/', (req, res) => {
        res.sendFile(path.join(__dirname,'..','views','index.html'));
    });

    // about page
    app.get('/about', (req, res) => {
        res.sendFile(path.join(__dirname,'..','views','about.html'));
    });

    // services page
    app.get('/services', (req, res) => {
        res.sendFile(path.join(__dirname,'..','views','services.html'));
    });

    // contact page
    app.get('/contact', (req, res) => {
        res.sendFile(path.join(__dirname,'..','views','contact.html'));
    });

    // 404
    app.use((req,res) => {
        res.sendFile(path.join(__dirname,'..','views','404.html'));
    });
};

module.exports = {
    mapRoutes
};