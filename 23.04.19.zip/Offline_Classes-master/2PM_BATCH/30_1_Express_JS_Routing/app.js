const path = require('path');
const router = require('./router/appRoutes');
const express = require('express');
const app = express();
const hostname = '127.5.5.1';
const port = 8000;

// Middleware for static files
app.use('/public',express.static('public'));

// Routing
router.mapRoutes(app);


app.listen(port,hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});