$('#green-btn').click(function() {
    $('#green-card').toggle(1000);
    let btnText = $(this).text();
    if(btnText === 'HIDE'){
        $(this).text('SHOW');
    }
    else{
        $(this).text('HIDE');
    }
});

/* ---------- Display Text ------------ */
$('#username').keyup(function() {
    $('#display').text($(this).val());
});

// SMS App
let maxLength = 100;
$('#text-area').keyup(function() {
    let textEnteredLength = $(this).val().length;
    $('#span').text(maxLength - textEnteredLength);
});

// Display Cities
let cities = ['HYDERABAD','BANGALORE','CHENNAI','NOIDA','DELHI'];
let options = `<option value="">Select a City</option>`;
for(let city of cities){
    options += `<option value="${city}">${city}</option>`
}
$('#city').empty().append(options);

$('#city').change(function() {
    $('#display-city').text($(this).val());
});

// Show Password
$('#checkbox').change(function() {
    let passwordBox = $('#password');
    if(passwordBox.attr('type') === 'password'){
        passwordBox.attr('type','text');
    }
    else{
        passwordBox.attr('type','password');
    }
});


